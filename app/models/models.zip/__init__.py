from .sumit import Doctor
from .sumit import Specialty
from .sumit import Medical_Center
from .sumit import Insurer
# from .workspaces import Workspaces
# from .ws_data import WSData